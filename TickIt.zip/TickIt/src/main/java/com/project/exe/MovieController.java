package com.project.exe;

import java.io.IOException;
import java.util.Scanner;

import com.project.services.ForgetPassword;
import com.project.services.UserService;

public class MovieController {

	public static void main(String[] args) throws ClassNotFoundException, IOException 
	{
		MovieController MC = new MovieController();
		MC.movieMain();
		
	
	}
	public void movieMain() throws ClassNotFoundException, IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("----------------------------------------------------------------");
		System.out.println("                    Welcome to TickIt                           ");
		System.out.println("----------------------------------------------------------------");
		System.out.println("1. User Login");
		System.out.println("2. Admin Login");
		System.out.println("3. Forget Password");
		System.out.println("4. Exit");
		System.out.println("----------------------------------------------------------------");
		System.out.println("Enter your choice: ");
		int choice = sc.nextInt();
		
		switch(choice)
		{
			case 1:
				System.out.println("Existing User(Press E) or New User(Press N)");
				String s = sc.nextLine();
				
			case 2:
				//AdminService.login();
			case 3:
				//ForgetPassword.forgetPassword(sc);
			case 4:
				System.out.println(0);
		}
	}
}
