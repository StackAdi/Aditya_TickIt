package com.project.dto;

public class Admin {
	
	int userId;
	String adminName;
	String password;
	int adminContact;
	public Admin(int userId, String adminName, String password, int adminContact) {
		super();
		this.userId = userId;
		this.adminName = adminName;
		this.password = password;
		this.adminContact = adminContact;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAdminContact() {
		return adminContact;
	}
	public void setAdminContact(int adminContact) {
		this.adminContact = adminContact;
	}
	
}
